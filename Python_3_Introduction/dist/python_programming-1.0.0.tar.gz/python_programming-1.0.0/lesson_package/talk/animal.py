from lesson_package.tools import utils
# from ..tools import utils

def sing():
    return 'kjahikfgseruihgolh'

def cry():
    return utils.say_twice('ijdbiuahgihaojapo')